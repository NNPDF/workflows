*     -*- fortran -*-

      integer NPX,NPQ2,MXREP
      parameter(NPX=100,NPQ2=50,MXREP=1e3)

      integer IX,IQ2
      double precision Q2MIN
      double precision XG(NPX),Q2G(NPQ2),XPDFEV(NPX,NPQ2,-6:6,0:MXREP)
      common/CPDFGR/XPDFEV,XG,Q2G,Q2MIN,IX,IQ2

*     --------------------------------------------
