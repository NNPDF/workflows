#!/bin/bash


####################################
#
# Script to run FONLLdis program
#
####################################

# Compile and run
make clean
make 

# Run with toy LH PDFs
# to reproduce the LH HQ benchmarks

# Set parameters
# Q2=4      # in GeV2
Q2LIST="2 4 10 24 100"
SF='F2'    # Structure function to plot
scheme='A' # FONLL scheme
PDFset=0   # 0 for LH toy PDFs
nx=2       # number of points in the LH benchmarks

for Q2 in $Q2LIST
do
# FONLLdis
  ./FONLLdis <<EOF
$Q2
$SF
$scheme
$PDFset
$nx
EOF
mv FONLLdis-ToyLH.res FONLLdis-ToyLH-Q2-$Q2-scheme-$scheme.res
done


###################################

