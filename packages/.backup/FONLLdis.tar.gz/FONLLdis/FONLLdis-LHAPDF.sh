#!/bin/bash


####################################
#
# Script to run FONLLdis program
#
####################################

# Compile and run
make clean
make 


# Set parameters
Q2=10      # in GeV2
SF='F2'    # Structure function to plot
scheme='A' # FONLL scheme
PDFset=1   # 1 for LHAPDF
PDFname='NNPDF10_100.LHgrid'
mc2=2
mb2=25
mt2=1000000
nx=10       # number of points for plotting

# FONLLdis
./FONLLdis <<EOF
$Q2
$SF
$scheme
$PDFset
$PDFname
$mc2,$mb2,$mt2
$nx
EOF

###################################

