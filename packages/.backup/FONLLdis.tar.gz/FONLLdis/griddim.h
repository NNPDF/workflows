
      integer mxnxgrid
      parameter(mxnxgrid=100)
      integer nxgrid
      common/cnxtab/nxgrid
