*     ---------------------------------------------------
*
*     FONLLdis	v0.1
*    
*     Program for the computation of the charm structure function
*     in Deep-Inelastic Scattering up to NNLO
*     based in the FONLL General-Mass scheme
*
*     Authors:
*     S. Forte,  E. Laenen, P. Nason and J. Rojo
*     Contact:
*     Paolo Nason <paolo.nason@mib.infn.it>
*     Juan Rojo <juan.rojo@mi.infn.it>
*
*
*     The light quark contributions to F2 and FL 
*     (the contribution where the photon interacts with light quarks) 
*     is not included in v0.1 of FONLLdis. It will however be included 
*     in future releases of the program.
*
*     Note in any case that as shown in arXiv:1001.2312 this contribution 
*     is numerically equivalent to its MSbar counterpart. In other words, 
*     it can be safely
*     computed using a standard packages like QCDNUM
*     or HOPPET, using the standard massless approach.
*
*     --------------------------------------------------------
*
*     REFERENCES:
*     
*     The FONLL approach for Deep-Inelastic Scattering 
*     is described in:
*     
*     'Heavy quarks in deep-inelastic scattering'.
*     Stefano Forte, Eric Laenen, Paolo Nason, Juan Rojo
*     e-Print: arXiv:1001.2312 [hep-ph]
*     Nucl.Phys.B834:116-162,2010
*
*     For the PDF evolution and ZM-VFN scheme coefficient
*     functions, the program uses the QCDNUM package
*     http://www.nikhef.nl/~h24/qcdnum/
*
*     The O(as^2) heavy quark massive coefficient functions are
*     obtained from the original expressions first presented
*     in Ref. 'Complete O (alpha-s) corrections to heavy flavor 
*     structure functions in electroproduction'
*     Eric Laenen, S. Riemersma, J. Smith, W.L. van Neerven
*     Nucl.Phys.B392:162-228,1993. 
*
*     The description of the Les Houches benchmarks on 
*     Heavy quarks in Deep-Inelastic scattering can be found in:
*     'The SM and NLO Multileg Working Group: Summary report'.
*     e-Print: arXiv:1003.1241 [hep-ph] 
*
*     ------------------------------------------------------
*
*     USAGE:
*
*     FONLLdis v0.1 provides GM-VFN
*     charm structure functions in the three (A,B,C)
*     available FONLL schemes (as described in arXiv:1001.2312)
*
*     To run the code, edit either FONLLdis-LHHQ.sh (with the
*     LH HQ benchmark settings) or FONLLdis-LHAPDF.sh
*     (with the chosen LHAPDF PDF settings) to generate a table
*     with the ZM, FFN, FFN0 and FONLL results for the
*     charm structure function
*
*     For the LH settings the charm mass quark is fixed at its benchmark
*     value mc2 = 2 GeV2, in the LHAPDF option it can be set
*     by the user	
*
*     Alternatively, compile with make, run ./FONLLdis and follow
*     the instructions of the program
*
*     The output of FONLLdis is saved in the file FONLLdis-LHHQ.res
*     (if the LH Toy PDFs are used) or in FONLLdis-LHAPDF.res
*     if a PDF set from the LHAPDF package is used instead
*
*
*     ----------------------------------------------------------