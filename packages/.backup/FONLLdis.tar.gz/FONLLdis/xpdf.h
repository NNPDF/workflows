*           -*-fortran-*-

      double precision XPDF(mxnxgrid,2)
      common/CXPDF/XPDF
