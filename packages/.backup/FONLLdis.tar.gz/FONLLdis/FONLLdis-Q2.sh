#!/bin/bash


####################################
#
# Script to run FONLLdis program
#
####################################

# Compile and run
make clean
make 

# Run with toy LH PDFs
# to reproduce the LH HQ benchmarks

# Set parameters
# Q2=4      # in GeV2
Q2LIST="3 4 6 10 15 20 25 30 40 50 70 100 1000"
SF='F2'    # Structure function to plot
scheme='A' # FONLL scheme
PDFset=0   # 0 for LH toy PDFs

for Q2 in $Q2LIST
do
# FONLLdis
  ./FONLLdis <<EOF
$Q2
$SF
$scheme
$PDFset
EOF
mv FONLLdis-ToyLH.res FONLLdis-ToyLH-Q2-$Q2-scheme-$scheme.res
done


###################################

