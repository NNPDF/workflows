      real * 8 pi,pi2
      parameter (pi=3.141592653589793d0,pi2=pi**2)
