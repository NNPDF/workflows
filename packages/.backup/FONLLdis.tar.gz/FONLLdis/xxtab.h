*           -*-fortran-*-

c      integer nxtab, nqtab
c      double precision xxtab,xlxtab,qqtab,xmi,xma,qmi, qma
c      common /tabout/ xxtab(99),qqtab(99),
c     +     xmi,xma,qmi,qma,nxtab,nqtab
c      common /tabout2/xlxtab(99)
      integer nxtab
      double precision xxtab,xlxtab,xmi,xma
      common /tabout/ xxtab(99),xlxtab(99),xmi,xma,nxtab

