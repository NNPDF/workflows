#!/bin/bash


####################################
#
# Script to run FONLLdis program
#
####################################

# Compile and run
make clean
make 

# Run with toy LH PDFs
# to reproduce the LH HQ benchmarks

# Set parameters
Q2=10      # in GeV2
SF='F2'    # Structure function to plot
scheme='B' # FONLL scheme
PDFset=0   # 0 for LH toy PDFs
nx=3       # number of points in the LH benchmarks
isin=1     # Include only gluon contribution in O(as2) structure functions

# FONLLdis
./FONLLdis <<EOF
$Q2
$SF
$scheme
$PDFset
$isin
$nx
EOF

###################################

