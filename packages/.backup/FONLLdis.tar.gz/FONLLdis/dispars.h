      real * 8 xbj,q2,mq,ehq,as
      integer iford, iord, ioption
      character * 2 whichf
      logical asympt,withsinglet
      common/dispars/xbj,q2,mq,ehq,as,
     1     iford, iord, ioption,asympt,withsinglet,whichf

